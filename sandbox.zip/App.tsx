import React, { useState, ChangeEvent, MouseEvent } from 'react';

// --- Type Definitions ---
interface Material {
    name: string;
    basePrice: number;
    unit: 'm' | 'm²' | 'c/u' | 'pieza' | 'metro' | 'mm';
    qtyFormula: (w: number, h: number) => number;
    sizeFormula: (w: number, h: number) => string | number;
    isConfigurable: boolean;
}

interface ResultRow {
    name: string;
    quantity: number;
    size: string | number;
    cost: number;
}

interface CalculationData {
    materials: Material[];
    glassFormula?: (w: number, h: number) => { quantity: number; width: number; height: number; areaM2?: number }[];
    felpaFormula?: (w: number, h: number) => number; // in mm
    vinilFormula?: (w: number, h: number) => number; // in mm
    diagramLabel: string;
}

// --- Helper Functions ---
const mmToM = (mm: number): number => mm / 1000;
const mm2ToM2 = (mm2: number): number => mm2 / 1000000;

// --- Material Definitions & Calculation Logic ---
const itemDefinitions: { [key: string]: CalculationData } = {
    // --- Ventanas ---
    ventana_corrediza: {
        diagramLabel: "Ventana Corrediza",
        materials: [
            { name: 'Jamba con mosquitero de 3”', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Jamba de 3”', basePrice: 100, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 26, isConfigurable: true },
            { name: 'Riel de 3”', basePrice: 90, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Adaptador Mosquitero', basePrice: 60, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Zoclo de 3”', basePrice: 110, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w) => (w - 185) / 2, isConfigurable: true },
            { name: 'Cabezal de 3”', basePrice: 70, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w) => (w - 185) / 2, isConfigurable: true },
            { name: 'Cerco chapa de 3” (fijo)', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 30, isConfigurable: true },
            { name: 'Traslape de 3” (fijo)', basePrice: 90, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 30, isConfigurable: true },
            { name: 'Cerco chapa de 3” (móvil)', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 40, isConfigurable: true },
            { name: 'Traslape de 3” (móvil)', basePrice: 90, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 40, isConfigurable: true },
            { name: 'Vertical mosquitero', basePrice: 70, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 20, isConfigurable: true },
            { name: 'Horizontal mosquitero', basePrice: 70, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w) => (w - 25) / 2, isConfigurable: true },
            { name: 'Carretillas p/ 3”', basePrice: 20, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Jaladera de embutir', basePrice: 90, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Carretillas p/mosquitero', basePrice: 15, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Carretillas de fleje', basePrice: 13, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Contraplana', basePrice: 18, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Tela mosquitero', basePrice: 50, unit: 'm²', qtyFormula: () => 1, sizeFormula: (w, h) => `${((w - 25) / 2) * 2} x ${h - 20} mm`, isConfigurable: true }, // Approx area
            { name: 'Sellador acrilico', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
        ],
        glassFormula: (w, h) => [
            { quantity: 1, width: (w - 151) / 2, height: h - 125, areaM2: mm2ToM2(((w - 151) / 2) * (h - 125)) }, // Fijo
            { quantity: 1, width: (w - 151) / 2, height: h - 135, areaM2: mm2ToM2(((w - 151) / 2) * (h - 135)) }, // Móvil
        ],
        felpaFormula: (w, h) => (w * 4) + (h * 8),
        vinilFormula: (w, h) => (w * 2) + (h * 4),
    },
    ventanal_oxxo: {
        diagramLabel: "Ventanal Oxxo",
        materials: [
            { name: 'Riel de 3"', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Jamba c/mosquitero 3"', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Jambas de 3"', basePrice: 100, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 26, isConfigurable: true },
            { name: 'Adaptador mosquitero', basePrice: 60, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Zoclo de 3"', basePrice: 100, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w) => (w - 330) / 4, isConfigurable: true },
            { name: 'Cabezal de 3"', basePrice: 70, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w) => (w - 330) / 4, isConfigurable: true },
            { name: 'Cerco chapa de 3" (fijo)', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 30, isConfigurable: true },
            { name: 'Cerco chapa de 3" (móvil)', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 40, isConfigurable: true },
            { name: 'Traslape de 3" (fijo)', basePrice: 90, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 30, isConfigurable: true },
            { name: 'Traslape de 3" (móvil)', basePrice: 90, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 40, isConfigurable: true },
            { name: 'Vertical mosquitero', basePrice: 70, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w, h) => h - 20, isConfigurable: true }, // Assuming 2 mosquito nets
            { name: 'Horizontal mosquitero', basePrice: 70, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w) => (w - 10) / 4, isConfigurable: true }, // Check width calc logic
            { name: 'Adaptador oxxo', basePrice: 60, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 50, isConfigurable: true },
            { name: 'Carretillas de 3"', basePrice: 20, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Jaladera de embutir', basePrice: 90, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Contras planas', basePrice: 20, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Carretillas p/mosquitero', basePrice: 15, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Carretillas de fleje', basePrice: 18, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Sellador acrílico', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
        ],
        glassFormula: (w, h) => [
            { quantity: 2, width: (w - 265) / 4, height: h - 125, areaM2: mm2ToM2(((w - 265) / 4) * (h - 125)) }, // Fijos
            { quantity: 2, width: (w - 265) / 4, height: h - 135, areaM2: mm2ToM2(((w - 265) / 4) * (h - 135)) }, // Móviles
        ],
        felpaFormula: (w, h) => (w * 5) + (h * 10),
        vinilFormula: (w, h) => (w * 2) + (h * 8), // Assuming Vinil del 11 peine is standard vinil calculation here
    },
    ventana_3_hojas: {
        diagramLabel: "Ventanal 3 Hojas Telescópica",
        materials: [
            { name: 'Riel de 3”', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Jamba de 3” (cabezal)', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true },
            { name: 'Jambas de 3”', basePrice: 100, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 26, isConfigurable: true },
            { name: 'Adaptador paloma', basePrice: 40, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 65, isConfigurable: true },
            { name: 'Zoclo de 3”', basePrice: 110, unit: 'metro', qtyFormula: () => 3, sizeFormula: (w) => (w - 167) / 3, isConfigurable: true },
            { name: 'Cabezal De 3”', basePrice: 70, unit: 'metro', qtyFormula: () => 3, sizeFormula: (w) => (w - 167) / 3, isConfigurable: true },
            { name: 'Cerco chapa de 3” (fijo)', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h, isConfigurable: true },
            { name: 'Cerco chapa de 3” (móvil)', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 40, isConfigurable: true }, // Only 1 specified as mobile? Should be 2? Assuming 1 for now.
            { name: 'Traslape de 3” (fijo)', basePrice: 90, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h, isConfigurable: true },
            { name: 'Traslape de 3” (móvil)', basePrice: 90, unit: 'metro', qtyFormula: () => 3, sizeFormula: (w, h) => h - 40, isConfigurable: true }, // 3 restantes = 3 mobile
            { name: 'Carretillas De 3”', basePrice: 20, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming 2 per mobile panel (2 mobile panels?)
            { name: 'Jaladera de embutir', basePrice: 80, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Uñero', basePrice: 40, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
            { name: 'Sellador acrilico', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
        ],
        glassFormula: (w, h) => [
            { quantity: 1, width: (w - 117) / 3, height: h - 95, areaM2: mm2ToM2(((w - 117) / 3) * (h - 95)) }, // Fijo
            { quantity: 2, width: (w - 117) / 3, height: h - 135, areaM2: mm2ToM2(((w - 117) / 3) * (h - 135)) }, // Móviles (assuming 2)
        ],
        felpaFormula: (w, h) => (w * 5) + (h * 8),
        vinilFormula: (w, h) => (w * 2) + (h * 9),
    },
    // --- Puertas ---
    puerta: {
        diagramLabel: "Puerta",
        materials: [
            { name: 'Bolsa lisa de 2” (cabezal)', basePrice: 100, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true }, // Assuming price
            { name: 'Batiente de ¾ (cabezal)', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 64, isConfigurable: true }, // Assuming price
            { name: 'Bolsa lisa de 2”', basePrice: 100, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 32, isConfigurable: true }, // Assuming price
            { name: 'Batiente de ¾', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 32, isConfigurable: true }, // Assuming price
            { name: 'Cerco chapa de 1 ¾', basePrice: 90, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 47, isConfigurable: true }, // Assuming price
            { name: 'Zoclo de 1 ¾', basePrice: 85, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 181, isConfigurable: true }, // Assuming price
            { name: 'Intermedio de 1 ¾', basePrice: 85, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 181, isConfigurable: true }, // Assuming price
            { name: 'Cabezal de 1 ¾', basePrice: 85, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 181, isConfigurable: true }, // Assuming price
            { name: 'Junquillos 1 ¾ horiz.', basePrice: 30, unit: 'metro', qtyFormula: () => 8, sizeFormula: (w) => w - 181, isConfigurable: true }, // Assuming price
            { name: 'Junquillos 1 ¾ vert.', basePrice: 30, unit: 'metro', qtyFormula: () => 8, sizeFormula: (w, h) => (h - 245) / 2, isConfigurable: true }, // Assuming price
            { name: 'Tensores de acero', basePrice: 150, unit: 'c/u', qtyFormula: () => 2, sizeFormula: (w) => w - 110, isConfigurable: true }, // Assuming price
            { name: 'Pivote descentrado', basePrice: 200, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
            { name: 'Chapa doble manija', basePrice: 350, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
            { name: 'Sellador acrílico', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
        ],
        glassFormula: (w, h) => [
            { quantity: 2, width: w - 191, height: (h - 205) / 2, areaM2: mm2ToM2((w - 191) * ((h - 205) / 2)) }
        ],
        felpaFormula: (w, h) => h * 5,
        vinilFormula: (w, h) => (w * 4) + (h * 2),
    },
    puerta_ligera: {
        diagramLabel: "Puerta Ligera",
        materials: [
             { name: 'Batiente de 1 ½ (cabezal)', basePrice: 70, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 25, isConfigurable: true }, // Assuming price
             { name: 'Batiente de 1 ½', basePrice: 70, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h, isConfigurable: true }, // Assuming price
             { name: 'Cerco chapa de 3”', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 27, isConfigurable: true },
             { name: 'Zoclo de 3”', basePrice: 110, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 139, isConfigurable: true }, // Assuming 1 zoclo
             { name: 'Cabezal de 3”', basePrice: 70, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 139, isConfigurable: true }, // Added cabezal assuming similar to zoclo
             { name: 'Intermedio de 3”', basePrice: 75, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 139, isConfigurable: true }, // Assuming price
             // Duela calculation is complex - needs area input or assumption (e.g., half/half)
             // Simplified: Calculate total duela width needed if full, user adjusts price based on height/panels.
             { name: 'Panel de duela (ancho total)', basePrice: 150, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 121, isConfigurable: true }, // Price per linear meter of width? Needs clarification. Provide width.
             { name: 'Bisagras', basePrice: 50, unit: 'c/u', qtyFormula: () => 3, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             { name: 'Chapa doble manija', basePrice: 350, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             { name: 'Sellador acrílico', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true },
        ],
         // Glass calculation for half/half scenario
         glassFormula: (w, h) => [
            { quantity: 1, width: w - 121, height: (h - 180) / 2, areaM2: mm2ToM2((w - 121) * ((h - 180) / 2))}
         ],
         vinilFormula: (w, h) => (w * 4) + (h * 2), // Only if glass is present
         // Note: Duela quantity/size calculation is complex and depends on whether it's full or partial.
         // Added a simplified 'Panel de duela (ancho total)' entry.
         // User might need to specify duela height / glass height if mixed.
    },
    puerta_baño: {
        diagramLabel: "Puerta p/ Baño",
        materials: [
             { name: 'Silla de baño (cabezal)', basePrice: 90, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w - 30, isConfigurable: true }, // Assuming price
             { name: 'Silla de baño', basePrice: 90, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h, isConfigurable: true }, // Assuming price
             { name: 'Marco semilujo (horizontal)', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w) => w - 42, isConfigurable: true }, // Assuming price
             { name: 'Marco semilujo (vertical)', basePrice: 80, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 30, isConfigurable: true }, // Assuming price (corte 45)
             { name: 'Bisagra de piano', basePrice: 120, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h - 30, isConfigurable: true }, // Assuming price & size approx vertical marco
             { name: 'Jaladera trompa de elefante', basePrice: 40, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             { name: 'Resbalon', basePrice: 30, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             { name: 'Pasador de lujo', basePrice: 60, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             { name: 'Escuadras p/baño', basePrice: 10, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
             // Plastic/Glass needs type selection and price
             { name: 'Plástico / Vidrio Templado', basePrice: 300, unit: 'm²', qtyFormula: () => 1, sizeFormula: (w, h) => `${w - 112} x ${h - 100} mm`, isConfigurable: true },
        ],
        vinilFormula: (w, h) => (w * 2) + (h * 2), // Perimetral approx
    },
    puerta_cristal_templado: {
         diagramLabel: "Puerta Cristal Templado",
         materials: [
              { name: 'Bisagra muro/vidrio', basePrice: 500, unit: 'c/u', qtyFormula: () => 2, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
              { name: 'Jaladera teléfono ó pomo', basePrice: 400, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
              { name: 'Conector muro/vidrio', basePrice: 150, unit: 'c/u', qtyFormula: () => 3, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
              { name: 'Remate policarbonato', basePrice: 50, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w, h) => h, isConfigurable: true }, // Assuming price & size=height
              { name: 'Jaladera toallero (opcional)', basePrice: 600, unit: 'c/u', qtyFormula: () => 1, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
              // Vidrio templado calculated separately
         ],
         glassFormula: (w, h) => {
            const doorW = 700; // Standard width, could be input
            const doorH = h - 10;
            const fixedW = w - 20 - doorW;
            const fixedH = h;
            return [
                { quantity: 1, width: doorW, height: doorH, areaM2: mm2ToM2(doorW * doorH) }, // Puerta
                ...(fixedW > 0 ? [{ quantity: 1, width: fixedW, height: fixedH, areaM2: mm2ToM2(fixedW * fixedH) }] : []) // Fijo (if exists)
            ];
         },
         // No vinil/felpa typically
    },
    // --- Canceles de Baño ---
     cancel_plastico: {
        diagramLabel: "Cancel Plástico",
        materials: [
            { name: 'Riel de baño', basePrice: 80, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true }, // Assuming price
            { name: 'Guia de baño', basePrice: 70, unit: 'metro', qtyFormula: () => 1, sizeFormula: (w) => w, isConfigurable: true }, // Assuming price
            { name: 'Jambas de baño', basePrice: 85, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 30, isConfigurable: true }, // Assuming price
            { name: 'Horizontal para baño', basePrice: 75, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w) => (w + 30) / 2, isConfigurable: true }, // Assuming price - Check formula w+30? Seems unusual. Using as is.
            { name: 'Marco económico (vertical)', basePrice: 60, unit: 'metro', qtyFormula: () => 4, sizeFormula: (w, h) => h - 50, isConfigurable: true }, // Assuming price & vertical
            { name: 'Hojas de plastico', basePrice: 200, unit: 'm²', qtyFormula: () => 2, sizeFormula: (w, h) => `${(w - 30) / 2} x ${h - 80} mm`, isConfigurable: true }, // Assuming price per m2
            { name: 'Carretillas para baño H', basePrice: 25, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
            { name: 'Jaladera trompa de elefante', basePrice: 40, unit: 'c/u', qtyFormula: () => 4, sizeFormula: () => 'N/A', isConfigurable: true }, // Assuming price
        ],
        vinilFormula: (w, h) => ((w * 2) + (h * 2)) * 1.5, // Perimetral * 1.5
        // Standard height is 1880mm, but we allow input 'h'
    },
    cancel_cristal_templado: {
        diagramLabel: "Cancel Cristal Templado",
        materials: [
            { name: 'Kit de cancel de baño', basePrice: 1500, unit: 'c/u', qtyFormula: () => 1, sizeFormula: (w) => `Para ancho ${w}mm`, isConfigurable: true }, // Assuming price for a kit
            { name: 'Jambas (si no incluidas en kit)', basePrice: 100, unit: 'metro', qtyFormula: () => 2, sizeFormula: (w, h) => h - 30, isConfigurable: true }, // Optional/example
            // Vidrio templado calculated separately
        ],
        glassFormula: (w, h) => [
            { quantity: 2, width: (w + 50) / 2, height: h - 85, areaM2: mm2ToM2(((w + 50) / 2) * (h - 85)) }
        ],
        // No vinil/felpa typically
    },
    // --- Placeholders ---
    cancel_bacalar: { diagramLabel: "Cancel Bacalar (Cálculos Pendientes)", materials: [], },
    cancel_escuadra: { diagramLabel: "Cancel en Escuadra (Cálculos Pendientes)", materials: [], },
    cancel_escuadra_bacalar: { diagramLabel: "Cancel en Escuadra Bacalar (Cálculos Pendientes)", materials: [], },
    otros: { diagramLabel: "Otros (Pendiente)", materials: [], },
    historial: { diagramLabel: "Historial (Pendiente)", materials: [], },
};

// Base prices for consumables (per meter/m2)
const BASE_CONSUMABLE_PRICES = {
    vidrio: 300, // per m²
    felpa: 2,    // per meter (1000mm)
    vinil: 10,   // per meter (1000mm)
};

// --- Component ---
const CalculadoraMundoCancel: React.FC = () => {
    const [activeMenu, setActiveMenu] = useState<string | null>(null);
    const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);
    const [width, setWidth] = useState<string>('');
    const [height, setHeight] = useState<string>('');
    const [materialsData, setMaterialsData] = useState<{ [key: string]: number }>({});
    const [results, setResults] = useState<ResultRow[]>([]);
    const [totalCost, setTotalCost] = useState<number>(0);
    const [showResults, setShowResults] = useState<boolean>(false);
    const [calculationError, setCalculationError] = useState<string | null>(null);

    const handleMenuClick = (menu: string) => {
        setActiveMenu(menu);
        setActiveSubMenu(null); // Reset submenu when main menu changes
        setShowResults(false);
        setResults([]);
        setTotalCost(0);
        setWidth('');
        setHeight('');
        setMaterialsData({}); // Reset prices
        setCalculationError(null);
    };

    const handleSubMenuClick = (subMenu: string) => {
        setActiveSubMenu(subMenu);
        setShowResults(false);
        setResults([]);
        setTotalCost(0);
        setWidth('');
        setHeight('');
        setCalculationError(null);
        // Initialize material prices for the selected submenu
        const definition = itemDefinitions[subMenu];
        const initialPrices: { [key: string]: number } = {};
        if (definition?.materials) {
            definition.materials.forEach(mat => {
                if (mat.isConfigurable) {
                    initialPrices[mat.name] = mat.basePrice;
                }
            });
        }
         // Add consumable base prices if applicable
        if (definition?.glassFormula) initialPrices['Vidrio'] = BASE_CONSUMABLE_PRICES.vidrio;
        if (definition?.felpaFormula) initialPrices['Felpa'] = BASE_CONSUMABLE_PRICES.felpa;
        if (definition?.vinilFormula) initialPrices['Vinil'] = BASE_CONSUMABLE_PRICES.vinil;

        setMaterialsData(initialPrices);
    };

    const handlePriceChange = (materialName: string, value: string) => {
        const price = parseFloat(value);
        if (!isNaN(price)) {
            setMaterialsData(prev => ({ ...prev, [materialName]: price }));
        }
    };

    const handleCalculate = () => {
        setCalculationError(null);
        setShowResults(false);
        const w = parseFloat(width);
        const h = parseFloat(height);

        if (!activeSubMenu || isNaN(w) || isNaN(h) || w <= 0 || h <= 0) {
            setCalculationError("Por favor, ingrese Ancho y Alto válidos en milímetros.");
            return;
        }

        const definition = itemDefinitions[activeSubMenu];
        if (!definition) {
             setCalculationError("Definición de cálculo no encontrada para este item.");
             return;
        }

        const calculatedResults: ResultRow[] = [];
        let currentTotalCost = 0;

        try {
            // Calculate standard materials
            definition.materials.forEach(mat => {
                const quantity = mat.qtyFormula(w, h);
                const size = mat.sizeFormula(w, h);
                const price = materialsData[mat.name] ?? mat.basePrice;
                let cost = 0;
                let displaySize = typeof size === 'number' ? `${size.toFixed(1)} mm` : size;

                if (quantity > 0) {
                    switch (mat.unit) {
                        case 'metro':
                        case 'mm': // Treat mm length same as meter price for calculation base
                            const lengthM = mmToM(typeof size === 'number' ? size : 0);
                            cost = quantity * lengthM * price;
                            displaySize = `${(typeof size === 'number' ? size : 0).toFixed(1)} mm (${lengthM.toFixed(2)} m)`;
                            break;
                        case 'c/u':
                        case 'pieza':
                            cost = quantity * price;
                            break;
                        case 'm²':
                            // Area calculation might be complex, e.g., Tela mosquitero
                            // Simple approach: assume size formula gives area if unit is m²
                            // A better approach would be a dedicated areaFormula
                            // For now, if size is string, parse it or estimate. If number, assume it's mm2
                             if (typeof size === 'string' && size !== 'N/A') {
                                // Basic parsing attempt 'W x H mm'
                                const dims = size.match(/([\d.]+)\s*x\s*([\d.]+)/);
                                if (dims) {
                                    const areaM2 = mm2ToM2(parseFloat(dims[1]) * parseFloat(dims[2]));
                                     cost = quantity * areaM2 * price;
                                     displaySize = `${size} (${areaM2.toFixed(2)} m²)`;
                                } else {
                                    // Cannot parse area from string, maybe use base estimate or flag error
                                    cost = quantity * price; // Fallback? Or set to 0/error
                                    console.warn(`Could not calculate area cost for ${mat.name}`);
                                }
                            } else if(typeof size === 'number'){
                                const areaM2 = mm2ToM2(size);
                                cost = quantity * areaM2 * price;
                                displaySize = `${size.toFixed(1)} mm² (${areaM2.toFixed(2)} m²)`;
                            } else {
                                cost = quantity * price; // Fallback for 'N/A' or other cases
                            }
                            break;
                        default:
                            cost = 0; // Unknown unit
                    }
                }


                calculatedResults.push({
                    name: mat.name,
                    quantity: quantity,
                    size: displaySize,
                    cost: cost
                });
                currentTotalCost += cost;
            });

            // Calculate Glass
            if (definition.glassFormula) {
                const glassPrice = materialsData['Vidrio'] ?? BASE_CONSUMABLE_PRICES.vidrio;
                const glasses = definition.glassFormula(w, h);
                glasses.forEach((glass, index) => {
                    if (glass.quantity > 0 && glass.width > 0 && glass.height > 0) {
                        const areaM2 = glass.areaM2 ?? mm2ToM2(glass.width * glass.height);
                        const cost = glass.quantity * areaM2 * glassPrice;
                        calculatedResults.push({
                            name: `Vidrio #${index + 1}`,
                            quantity: glass.quantity,
                            size: `${glass.width.toFixed(1)} x ${glass.height.toFixed(1)} mm (${areaM2.toFixed(3)} m²)`,
                            cost: cost
                        });
                        currentTotalCost += cost;
                    }
                });
            }

            // Calculate Felpa
            if (definition.felpaFormula) {
                 const felpaLengthMm = definition.felpaFormula(w, h);
                 if (felpaLengthMm > 0) {
                     const felpaPricePerM = materialsData['Felpa'] ?? BASE_CONSUMABLE_PRICES.felpa;
                     const felpaLengthM = mmToM(felpaLengthMm);
                     const cost = felpaLengthM * felpaPricePerM;
                     calculatedResults.push({
                         name: 'Felpa',
                         quantity: 1, // Typically sold/calculated as total length needed
                         size: `${felpaLengthMm.toFixed(1)} mm (${felpaLengthM.toFixed(2)} m)`,
                         cost: cost
                     });
                     currentTotalCost += cost;
                 }
            }

             // Calculate Vinil
            if (definition.vinilFormula) {
                 const vinilLengthMm = definition.vinilFormula(w, h);
                  if (vinilLengthMm > 0) {
                     const vinilPricePerM = materialsData['Vinil'] ?? BASE_CONSUMABLE_PRICES.vinil;
                     const vinilLengthM = mmToM(vinilLengthMm);
                     const cost = vinilLengthM * vinilPricePerM;
                     calculatedResults.push({
                         name: 'Vinil',
                         quantity: 1, // Typically sold/calculated as total length needed
                         size: `${vinilLengthMm.toFixed(1)} mm (${vinilLengthM.toFixed(2)} m)`,
                         cost: cost
                     });
                     currentTotalCost += cost;
                 }
            }

            setResults(calculatedResults);
            setTotalCost(currentTotalCost);
            setShowResults(true);

         } catch (error) {
             console.error("Calculation Error:", error);
             setCalculationError(`Error durante el cálculo: ${error instanceof Error ? error.message : String(error)}`);
             setShowResults(false);
             setResults([]);
             setTotalCost(0);
         }
    };

    const renderMenuButton = (key: string, label: string) => (
        <button
            key={key}
            onClick={() => handleMenuClick(key)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeMenu === key
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
        >
            {label}
        </button>
    );

     const renderSubMenuButton = (key: string, label: string) => (
        <button
            key={key}
            onClick={() => handleSubMenuClick(key)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors w-full text-left ${activeSubMenu === key
                    ? 'bg-indigo-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
        >
            {label}
        </button>
    );

    const currentDefinition = activeSubMenu ? itemDefinitions[activeSubMenu] : null;

    return (
        <div className="p-4 md:p-6 bg-gray-50 min-h-screen font-sans">
            <h1 className="text-2xl md:text-3xl font-bold text-center text-gray-800 mb-6">Calculadora Mundo Cancel</h1>

            {/* Main Menu */}
            <div className="flex flex-wrap justify-center gap-3 mb-6">
                {renderMenuButton('ventanas', 'Ventanas')}
                {renderMenuButton('puertas', 'Puertas')}
                {renderMenuButton('canceles', 'Canceles de Baño')}
                {renderMenuButton('otros', 'Otros')}
                {renderMenuButton('historial', 'Historial')}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Sub Menu Column */}
                <div className="md:col-span-1 bg-white p-4 rounded-lg shadow">
                    <h2 className="text-lg font-semibold text-gray-700 mb-4">Seleccione Tipo</h2>
                    {activeMenu === 'ventanas' && (
                        <div className="space-y-2">
                            {renderSubMenuButton('ventana_corrediza', '1. Ventana Corrediza')}
                            {renderSubMenuButton('ventanal_oxxo', '2. Ventanal tipo Oxxo')}
                            {renderSubMenuButton('ventana_3_hojas', '3. Ventanal de 3 Hojas')}
                        </div>
                    )}
                    {activeMenu === 'puertas' && (
                        <div className="space-y-2">
                            {renderSubMenuButton('puerta', '1. Puerta')}
                            {renderSubMenuButton('puerta_ligera', '2. Puerta Ligera')}
                            {renderSubMenuButton('puerta_baño', '3. Puerta p/ Baño')}
                            {renderSubMenuButton('puerta_cristal_templado', '4. Puerta Cristal Templado')}
                        </div>
                    )}
                     {activeMenu === 'canceles' && (
                        <div className="space-y-2">
                            {renderSubMenuButton('cancel_plastico', '1. Cancel Plástico')}
                            {renderSubMenuButton('cancel_cristal_templado', '2. Cancel Cristal Templado')}
                            {renderSubMenuButton('cancel_bacalar', '3. Cancel Bacalar')}
                            {renderSubMenuButton('cancel_escuadra', '4. Cancel en Escuadra')}
                            {renderSubMenuButton('cancel_escuadra_bacalar', '5. Cancel Escuadra Bacalar')}
                        </div>
                    )}
                     {activeMenu === 'otros' && <p className="text-gray-500">Sección "Otros" pendiente.</p>}
                     {activeMenu === 'historial' && <p className="text-gray-500">Sección "Historial" pendiente.</p>}
                     {!activeMenu && <p className="text-gray-500">Seleccione una opción del menú principal.</p>}
                </div>

                {/* Calculation/Results Column */}
                <div className="md:col-span-2 space-y-6">
                    {activeSubMenu && currentDefinition && (
                         <div className="bg-white p-4 rounded-lg shadow space-y-4">
                            <h3 className="text-xl font-semibold text-gray-800 mb-3">{currentDefinition.diagramLabel}</h3>

                            {/* Input Section */}
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                                <div className="sm:col-span-1">
                                    <label htmlFor="width" className="block text-sm font-medium text-gray-700 mb-1">Ancho (mm)</label>
                                    <input
                                        type="number"
                                        id="width"
                                        value={width}
                                        onChange={(e: ChangeEvent<HTMLInputElement>) => setWidth(e.target.value)}
                                        placeholder="Ej: 1500"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                                    />
                                </div>
                                <div className="sm:col-span-1">
                                    <label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-1">Alto (mm)</label>
                                    <input
                                        type="number"
                                        id="height"
                                        value={height}
                                        onChange={(e: ChangeEvent<HTMLInputElement>) => setHeight(e.target.value)}
                                        placeholder="Ej: 1200"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                                    />
                                </div>
                                <div className="sm:col-span-1">
                                    <button
                                        onClick={handleCalculate}
                                        className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition-colors text-sm"
                                        disabled={!width || !height}
                                    >
                                        Iniciar Cálculo
                                    </button>
                                </div>
                            </div>
                             {calculationError && (
                                <p className="text-red-600 text-sm mt-2">{calculationError}</p>
                             )}

                             {/* Material Prices Configuration */}
                             {Object.keys(materialsData).length > 0 && (
                                <div className="mt-4 pt-4 border-t">
                                     <h4 className="text-md font-semibold text-gray-700 mb-2">Precios de Materiales (Configurable)</h4>
                                     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                         {Object.entries(materialsData).map(([name, price]) => {
                                            // Find the unit for display
                                            let unitDisplay = '';
                                            const matDefinition = currentDefinition.materials.find(m => m.name === name);
                                            if(matDefinition) unitDisplay = `(${matDefinition.unit})`;
                                            else if (name === 'Vidrio') unitDisplay = '(m²)';
                                            else if (name === 'Felpa' || name === 'Vinil') unitDisplay = '(metro)';

                                             return (
                                                 <div key={name} className="flex items-center space-x-2">
                                                     <label htmlFor={`price-${name}`} className="text-sm text-gray-600 flex-1 truncate" title={name}>
                                                         {name} <span className="text-xs text-gray-500">{unitDisplay}</span>:
                                                     </label>
                                                     <input
                                                         type="number"
                                                         id={`price-${name}`}
                                                         value={price}
                                                         onChange={(e) => handlePriceChange(name, e.target.value)}
                                                         className="w-20 px-2 py-1 border border-gray-300 rounded-md shadow-sm text-sm"
                                                         step="0.01"
                                                     />
                                                 </div>
                                             );
                                          })}
                                     </div>
                                </div>
                             )}
                        </div>
                    )}

                     {/* Results Section */}
                    {showResults && currentDefinition && (
                        <div className="bg-white p-4 rounded-lg shadow space-y-4">
                             <h3 className="text-xl font-semibold text-gray-800">Resultados del Cálculo</h3>

                             {/* Results Table */}
                             <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200 border border-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">A: Material</th>
                                            <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">B: Piezas</th>
                                            <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">C: Medida</th>
                                            <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">D: Costo</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                        {results.map((row, index) => (
                                            <tr key={index}>
                                                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{row.name}</td>
                                                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{row.quantity.toFixed(0)}</td>
                                                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{row.size}</td>
                                                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 font-medium">${row.cost.toFixed(2)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot className="bg-gray-100">
                                        <tr>
                                            <td colSpan={3} className="px-4 py-2 text-right text-sm font-bold text-gray-700">Costo Total:</td>
                                            <td className="px-4 py-2 text-left text-sm font-bold text-gray-900">${totalCost.toFixed(2)}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            {/* Diagram Placeholder */}
                             <div className="mt-4 pt-4 border-t">
                                 <h4 className="text-md font-semibold text-gray-700 mb-2">Diagrama (Referencia)</h4>
                                 <div className="flex justify-center items-center border-2 border-dashed rounded-xl p-4 min-h-32 bg-gray-100">
                                     <div className="text-center text-gray-500">
                                         <p className='font-medium'>{currentDefinition.diagramLabel}</p>
                                         <p>Ancho: {width} mm</p>
                                         <p>Alto: {height} mm</p>
                                         <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 mx-auto mt-2"></div>
                                     </div>
                                 </div>
                             </div>

                             {/* Action Buttons */}
                             <div className="flex flex-wrap justify-end gap-3 mt-4 pt-4 border-t">
                                <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded-md transition-colors">Guardar</button>
                                <button className="px-4 py-2 bg-teal-500 hover:bg-teal-600 text-white text-sm rounded-md transition-colors">Compartir</button>
                                <button onClick={() => window.print()} className="px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white text-sm rounded-md transition-colors">Imprimir</button>
                             </div>
                        </div>
                    )}

                    {/* Placeholder for non-implemented items */}
                     {activeSubMenu && !currentDefinition?.materials.length && !currentDefinition?.glassFormula && (
                         <div className="bg-white p-4 rounded-lg shadow">
                              <h3 className="text-xl font-semibold text-gray-800 mb-3">{currentDefinition?.diagramLabel ?? activeSubMenu}</h3>
                             <p className="text-gray-500">Los cálculos para este tipo de elemento aún no están implementados.</p>
                         </div>
                     )}
                </div>
            </div>
        </div>
    );
};

export default CalculadoraMundoCancel;